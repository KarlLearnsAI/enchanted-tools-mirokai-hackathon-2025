import asyncio
from functools import wraps, partial
from typing import Any, Callable


def make_async(func: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator to make a function asynchronous and handle both sync and async calls.

    Args:
        func (Callable[..., Any]): The function to make asynchronous.

    Returns:
        Callable[..., Any]: The asynchronous version of the function.
    """

    @wraps(func)
    async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # Run the function in an executor if the event loop is already running
                partial_func = partial(func, *args, **kwargs)
                return await loop.run_in_executor(None, partial_func)

            # Run the function directly if no event loop is running
            return func(*args, **kwargs)
        except RuntimeError:
            return sync_wrapper(*args, **kwargs)

    @wraps(func)
    def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # Run the function in an executor if the event loop is already running
                partial_func = partial(func, *args, **kwargs)
                future = loop.run_in_executor(None, partial_func)
                return asyncio.ensure_future(future)

            # Create a new event loop if no event loop exists
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            result = loop.run_until_complete(async_wrapper(*args, **kwargs))
            loop.close()
            return result
        except RuntimeError:
            # No event loop exists, so create one
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            result = loop.run_until_complete(async_wrapper(*args, **kwargs))
            loop.close()
            return result

    return sync_wrapper
