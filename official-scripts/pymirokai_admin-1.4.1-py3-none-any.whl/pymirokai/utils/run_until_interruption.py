"""Run an async function until interrupted."""

import asyncio
from typing import Callable, Awaitable
import signal


def run_until_interruption(callback: Callable[[], Awaitable[None]]) -> None:
    """Run an async callback that raises asyncio.CancelledError when SIGINT or SIGTERM is raised.

    Args:
        callback (Callable[[], Awaitable[None]]): The async function to run until interrupted.
    """
    loop = asyncio.get_event_loop()

    def handle_exit(loop: asyncio.AbstractEventLoop) -> None:
        for task in asyncio.all_tasks(loop):
            task.cancel()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, handle_exit, loop)
        except asyncio.CancelledError:
            print("Tasks were cancelled")
        except Exception as e:
            print(f"An error occurred: {e}")
    try:
        loop.run_until_complete(_async_cancelled_error_catcher(callback))
    finally:
        loop.run_until_complete(loop.shutdown_asyncgens())
        loop.close()


async def _async_cancelled_error_catcher(callback: Callable[[], Awaitable[None]]) -> None:
    """Run the async callback and catch asyncio.CancelledError.

    Args:
        callback (Callable[[], Awaitable[None]]): The async function to run.
    """
    try:
        await callback()
    except asyncio.CancelledError:
        pass
