"""Get the local IP address of the machine."""

import socket


def get_local_ip() -> str:
    """Returns the current IP.

    Returns:
        str: The current IP address.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
    except Exception:  # pylint: disable=W0718
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip
