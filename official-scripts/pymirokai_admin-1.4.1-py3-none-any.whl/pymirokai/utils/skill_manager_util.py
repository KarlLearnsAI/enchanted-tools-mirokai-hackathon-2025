import asyncio
import inspect
import json
import logging

from pathlib import Path
from typing import Optional

from pymirokai.core.skill_manager import SkillManager
from pymirokai.robot import Robot, connect
from pymirokai.utils.run_until_interruption import run_until_interruption

UPLOAD_DIR = Path.home() / "custom_skills"


async def run_skill_manager(robot: Robot, upload_dir: str) -> None:
    """
    Run the skill manager and handle JSON-RPC commands to run skills.

    Args:
        robot (Robot): The robot instance to use for communication.
        upload_dir (str): The directory where custom skills are located.
    """
    while robot.running.is_set():  # Keep running while the robot is active
        try:
            while not (robot.rest_api.is_connected and robot.websocket_api.is_connected and robot.running.is_set()):
                await asyncio.sleep(1)
            skill_manager = SkillManager(upload_dir=upload_dir)

            # Start monitoring the upload directory for new or updated skills
            asyncio.create_task(skill_manager.monitor_loop())

            # Subscribe to the "RPC" channel for receiving skill requests
            await robot.subscribe("RPC_command")
            await robot.subscribe("skills_list_command")

            # Define a callback to handle incoming RPC requests
            async def rpc_callback(msg: dict):
                if msg["command"] == "run":
                    await run_skill(msg, robot, skill_manager)
                elif msg["command"] == "cancel":
                    await cancel_skill(msg, robot, skill_manager)

            async def send_skills_callback(msg: Optional[dict] = None):
                _ = msg
                await send_skills_list(robot, skill_manager)

            # Register the callback with the robot
            robot.register_callback("RPC_command", rpc_callback)
            robot.register_callback("skills_list_command", send_skills_callback)

            # Keep the manager running until an interruption
            while robot.rest_api.is_connected and robot.websocket_api.is_connected and robot.running.is_set():
                await send_skills_callback()
                await asyncio.sleep(1)

            if not robot.websocket_api.is_connected:
                logging.warning("API disconnected. Restarting skill manager...")

        except Exception as e:
            logging.error(f"Error in skill manager: {e}")
            await robot.publish(
                topic="skill_manager_errors",
                data=json.dumps(
                    {
                        "name": "skill_manager_errors",
                        "type": "str",
                        "data": str(e),
                    }
                ),
            )

        # Ensure a small delay before attempting to restart
        await asyncio.sleep(1)


async def send_skills_list(robot: Robot, skill_manager: SkillManager):
    """Send the list of available skills."""
    skill_manager.get_custom_skills_list()
    serialized_skills = skill_manager.serialize_skills()
    await robot.publish(
        topic="skills_list_result",
        data=json.dumps(
            {
                "name": "skills_list_result",
                "type": "dict",
                "data": serialized_skills,
            }
        ),
    )


async def run_skill(msg: dict, robot: Robot, skill_manager: SkillManager):
    """
    Run a skill based on the JSON-RPC message and publish the result.

    Args:
        msg (str): JSON-RPC message containing the skill name and parameters.
        robot (Robot): The robot instance to use for publishing results.
        skill_manager (SkillManager): The skill manager to execute skills.
    """
    rpc_request = msg["data"]
    try:
        method = rpc_request.get("method")  # Skill name
        params = rpc_request.get("params", {})  # Skill parameters
        request_id = rpc_request.get("id", None)

        if not method:
            raise ValueError("Missing 'method' in the RPC request.")

        # Call the skill
        result = await skill_manager.call_skill(method, robot=robot, **params)
        logging.info(f"Running custom skill: {method}")

        if inspect.isawaitable(result):
            result = await result  # Ensure it's awaited

        # Prepare the response
        response = {
            "jsonrpc": "2.0",
            "result": result,  # Ensure it's a concrete value
            "id": request_id,
        }
    except Exception as e:
        # Handle any errors during skill execution
        response = {
            "jsonrpc": "2.0",
            "error": {
                "code": -32603,  # Internal error
                "message": str(e),
            },
            "id": rpc_request.get("id", None),
        }

    # Ensure response is serializable
    serialized_response = json.dumps(response, default=str)  # Convert any non-serializable data to string

    return_msg = {"name": "RPC_result", "type": "dict", "data": serialized_response}

    # Publish the result back
    await robot.publish(topic="RPC_result", data=json.dumps(return_msg))


async def cancel_skill(msg: dict, robot: Robot, skill_manager: SkillManager):
    """Cancel a running skill by its name.

    Args:
        msg (str): JSON message containing the skill name to cancel.
        robot (Robot): The robot instance to use for publishing results.
        skill_manager (SkillManager): The skill manager to cancell skills.."""
    result = await skill_manager.cancel_skill(msg["skill_name"])
    return_msg = {"name": "RPC_result", "request_id": msg["request_id"], "type": "dict", "data": result}
    await robot.publish(topic="RPC_result", data=json.dumps(return_msg))


async def internal_skill_manager():
    """Run the skill manager."""
    async with connect() as robot:
        await run_skill_manager(robot, UPLOAD_DIR)


def start_skill_manager():
    """Entry point for skill manager service."""
    run_until_interruption(internal_skill_manager)
