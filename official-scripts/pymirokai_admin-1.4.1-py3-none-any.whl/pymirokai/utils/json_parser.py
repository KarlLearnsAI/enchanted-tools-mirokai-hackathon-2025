import json
from typing import Union, Any


def parse_json_recursively(obj: Union[str, Any]) -> Any:
    """Parse a JSON string recursively.

    Args:
        obj (Union[str, Any]): The JSON string to parse or an already parsed JSON object.

    Returns:
        Any: The parsed JSON object or the original object if it's not a valid JSON string.
    """
    if isinstance(obj, str):
        try:
            obj = json.loads(obj)
        except json.JSONDecodeError:
            return obj

    if isinstance(obj, dict):
        for key, value in obj.items():
            obj[key] = parse_json_recursively(value)
    elif isinstance(obj, list):
        obj = [parse_json_recursively(element) for element in obj]

    return obj
