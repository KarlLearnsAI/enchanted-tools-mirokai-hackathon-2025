#!/usr/bin/env python3
"""This module contains the RestAPI class for communicating with the REST API."""

import asyncio
import logging
from pathlib import Path

from typing import Optional, Dict, Any
from aiohttp import ClientSession, client_exceptions, FormData, UnixConnector, TCPConnector
from pydantic import BaseModel

from pymirokai.api_version import API_VERSION
from pymirokai.utils.json_parser import parse_json_recursively

logger = logging.getLogger("pymirokai")


class RestAPI:
    """Class to handle REST API communication, supporting both Unix Domain Socket (UDS) and TCP/IP."""

    def __init__(
        self,
        api_version: str = API_VERSION,
        retry_interval: int = 5,
        uds_path: str = "/tmp/rest_api.sock",  # nosec
        use_uds: bool = False,
    ) -> None:
        """Initialize the RestAPI with the API URL.

        Args:
            api_version (str): Version of the API to use.
            retry_interval (int): The interval in seconds to wait before retrying the connection check.
            uds_path (str): Path to the Unix Domain Socket.
            use_uds (bool): Whether to use UDS, passed from robot.py.
        """
        self.uds_path = uds_path
        self.use_uds = use_uds
        self.api_url: Optional[str] = f"http+unix://{self.uds_path.replace('/', '%2F')}" if self.use_uds else None
        self.api_key: Optional[str] = None
        self.api_version = api_version
        self.retry_interval = retry_interval
        self.session: Optional[ClientSession] = None
        self.set_jwt_token = None
        self.get_jwt_token = None
        self.client_id = None
        self.access_level = None
        self.is_connected = False
        self.running = asyncio.Event()

    async def connect(self) -> None:
        """Check the connection status of the REST API and update the status."""
        while self.running.is_set():
            try:
                if not self.is_connected:
                    async with self.session.get(f"{self.api_url}/status", timeout=1) as response:
                        if response.status == 200:
                            if not self.is_connected:
                                logger.info("Connected to REST API.")
                            self.is_connected = True
                        else:
                            self.is_connected = False
                            logger.warning("Failed to connect to REST API. Retrying...")
            except (
                ConnectionError,
                ConnectionRefusedError,
                client_exceptions.ServerDisconnectedError,
                client_exceptions.ClientConnectorError,
                client_exceptions.ClientOSError,
            ) as e:
                logger.error(f"REST API connection error: {e}. Retrying...")
                self.is_connected = False
            await asyncio.sleep(self.retry_interval)

    async def setup_connection(self):
        """Get the JWT token and client_id, and retry until connected."""
        while self.running.is_set():
            try:
                logger.info(f"Attempting to connect to REST API at {self.api_url}")
                async with self.session.get(f"{self.api_url}/status", timeout=1) as response:
                    if response.status == 200:
                        logger.info("API responded successfully. Proceeding with authentication...")
                        await self.authentify()
                        if not self.get_jwt_token():
                            logger.error("Failed to get JWT token. Retrying...")
                            await asyncio.sleep(self.retry_interval)
                            continue
                        self.is_connected = True
                        logger.info("Connected to REST API.")
                        break  # Exit loop once connected
                    else:
                        logger.warning(f"Failed to connect to REST API. Status code: {response.status}. Retrying...")
            except (
                ConnectionError,
                client_exceptions.ClientOSError,
                client_exceptions.ServerDisconnectedError,
                client_exceptions.ClientConnectorError,
                asyncio.TimeoutError,
            ) as e:
                logger.error(f"REST API connection error: {e}. Retrying...")
            await asyncio.sleep(self.retry_interval)

    async def start(
        self,
        api_url: str,
        api_key: str,
        set_jwt_token: callable = None,
        get_jwt_token: callable = None,
        use_uds: bool = None,
    ) -> None:
        """Start the REST API session and connection check.

        Args:
            api_url (str): The API URL (ignored if UDS is used).
            api_key (str): API key (for TCP only).
            set_jwt_token (callable): Callback to set the JWT token.
            get_jwt_token (callable): Callback to get the JWT token.
        """
        if use_uds is None:
            use_uds = self.use_uds
        if use_uds:
            self.api_url = "http://localhost"
            logger.info(f"Using UDS connection: {self.api_url}")
            connector = UnixConnector(path=self.uds_path)
        else:
            self.api_url = api_url
            logger.info(f"Using TCP connection: {self.api_url}")
            connector = TCPConnector()

        self.api_key = api_key
        self.set_jwt_token = set_jwt_token
        self.get_jwt_token = get_jwt_token
        self.session = ClientSession(connector=connector)
        self.running.set()
        await self.setup_connection()

    async def authentify(self) -> None:
        """Retrieve the JWT token for authentication.
        - If UDS, assume a default local authentication.
        - If TCP, authenticate normally.
        """
        headers = {"X-API-Key": self.api_key}
        try:
            async with self.session.get(f"{self.api_url}/api/{self.api_version}/auth/", headers=headers) as response:
                if response.status == 200:
                    data = await response.json()
                    token = data.get("token")
                    self.set_jwt_token(token)
                else:
                    logger.error(f"Authentication failed: {response.status}")
                    response.raise_for_status()
        except client_exceptions.ClientError as e:
            logger.error(f"Error during authentication: {e}")

    async def get_data_and_update_token_and_client_id(self, response) -> dict:
        """From a response from the API, recursively parse JSON, update client_id and JWT token."""
        data = parse_json_recursively(await response.json())
        auth = response.headers.get("Authorization")
        if auth:
            self.set_jwt_token(auth.split()[1])
            if "client_id" in data:
                self.client_id = data["client_id"]
                self.access_level = data["access_level"]
                logger.info(f"Client ID: {self.client_id} ; Access level: {self.access_level}")
        return data

    async def send_command(self, endpoint: str, model: BaseModel) -> dict:
        """Send a command to the specified endpoint.

        Args:
            endpoint (str): The endpoint to send the command to.
            model (BaseModel): The command model.

        Returns:
            Dict[str, Any]: The response from the API.
        """
        if not self.is_connected:
            logger.error("Not connected to REST API")
            return {}
        if not self.get_jwt_token():
            logger.error("No JWT token available. Authenticate first.")
            return {}
        if endpoint == "get":
            url = f"{self.api_url}/api/{self.api_version}/{endpoint}/{model.command}"
            headers = {"Authorization": f"Bearer {self.get_jwt_token()}"}
            async with self.session.get(url, headers=headers) as response:
                if response.status == 200:
                    return await self.get_data_and_update_token_and_client_id(response)
                response.raise_for_status()
        else:
            url = f"{self.api_url}/api/{self.api_version}/{endpoint}/"
            headers = {"Authorization": f"Bearer {self.get_jwt_token()}"}
            data = model.model_dump()
            async with self.session.post(url, json=data, headers=headers) as response:
                if response.status == 200:
                    return await self.get_data_and_update_token_and_client_id(response)
                response.raise_for_status()

    async def get_services(self, system: Optional[str] = None, service: Optional[str] = None) -> Dict[str, Any]:
        """Either get the list of available services, or the service logs of a specific service.

        Args:
            system (Optional[str]): The system to get a specific service (head/base).
            service (Optional[str]): The service name.

        Returns:
            Dict[str, Any]: The response from the API.
        """
        if not self.is_connected:
            logging.error("Not connected to REST API")
        if not system and not service:
            url = f"{self.api_url}/api/{self.api_version}/service/get_services_list"
            async with self.session.get(url) as response:
                if response.status == 200:
                    return await self.get_data_and_update_token_and_client_id(response)
                response.raise_for_status()
        elif not system or not service:
            logging.error("You must set either both service name and system (head/base), or none.")
        else:
            url = f"{self.api_url}/api/{self.api_version}/service/{system}/{service}"
            async with self.session.get(url) as response:
                if response.status == 200:
                    return await self.get_data_and_update_token_and_client_id(response)
        if not self.is_connected:
            logging.error("Not connected to REST API")

    async def upload_skill_file(self, skill_path: str) -> dict:
        """Upload a skill to the robot.

        Args:
            skill_path (str): Path to the Python skill to upload.

        Returns:
            dict: The response from the API.
        """
        if not self.is_connected:
            logger.error("Not connected to REST API")
            return {}

        url = f"{self.api_url}/api/{self.api_version}/skill/upload/"
        headers = {"Authorization": f"Bearer {self.get_jwt_token()}"}
        data = FormData()
        data.add_field("skill", open(skill_path, "rb"), filename=Path(skill_path).name)

        async with self.session.post(url, data=data, headers=headers) as response:
            if response.status == 200:
                return await response.json()
            response.raise_for_status()

    async def remove_skill_file(self, skill_name: str) -> dict:
        """Remove a skill from the robot.

        Args:
            skill_name (str): Name of the skill to remove.

        Returns:
            dict: The response from the API.
        """
        if not self.is_connected:
            logger.error("Not connected to REST API")
            return {}

        # Append skill_name as a query parameter
        url = f"{self.api_url}/api/{self.api_version}/skill/remove/?skill_name={skill_name}"
        headers = {"Authorization": f"Bearer {self.get_jwt_token()}"}

        async with self.session.delete(url, headers=headers) as response:
            if response.status == 200:
                return await response.json()
            response.raise_for_status()

    async def list_skill_files(self) -> dict:
        """Retrieve the list of uploaded skills.

        Returns:
            dict: The list of skills from the API.
        """
        if not self.is_connected:
            logger.error("Not connected to REST API")
            return {}

        url = f"{self.api_url}/api/{self.api_version}/skill/list/"
        headers = {"Authorization": f"Bearer {self.get_jwt_token()}"}

        async with self.session.get(url, headers=headers) as response:
            if response.status == 200:
                return await response.json()
            response.raise_for_status()

    async def enable_skill_file(self, skill_name: str, enable: bool) -> dict:
        """Enable or disable a skill on the robot.

        Args:
            skill_name (str): Name of the skill.
            enable (bool): Whether to enable or disable the skill.

        Returns:
            dict: The response from the API.
        """
        if not self.is_connected:
            logger.error("Not connected to REST API")
            return {}

        url = f"{self.api_url}/api/{self.api_version}/skill/enable/"
        headers = {"Authorization": f"Bearer {self.get_jwt_token()}"}
        payload = {"command": skill_name, "value": enable}

        async with self.session.patch(url, json=payload, headers=headers) as response:
            if response.status == 200:
                return await response.json()
            response.raise_for_status()

    async def close(self) -> None:
        """Close the REST API connection."""
        self.running.clear()
        await self.session.close()
        self.is_connected = False
        logger.info("REST API connection closed.")
