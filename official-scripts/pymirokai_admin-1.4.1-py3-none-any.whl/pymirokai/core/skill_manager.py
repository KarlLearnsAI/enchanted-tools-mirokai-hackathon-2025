import asyncio
import importlib
import inspect
import json
import logging
import os

from collections.abc import Iterable
from pathlib import Path
from typing import Any, Dict, List

from pymirokai.robot import Robot


LOG = logging.getLogger("pymirokai")


class SkillManager:
    def __init__(self, upload_dir: Path):
        self.upload_dir = upload_dir
        self.get_custom_skills_list()
        self.running_skills: Dict[str, asyncio.Task] = {}

    def get_custom_skills_list(self) -> List[Dict[str, Any]]:
        """
        Analyze all Python files in the given directory to find functions decorated with @custom_skill(...)
        and extract their metadata and function prototypes.

        Returns:
            List[Dict[str, Any]]: A list of dictionaries, each containing the details of a decorated function.
        """
        result = {}

        for root, _, files in os.walk(self.upload_dir):
            for filename in files:
                if filename.endswith(".py"):
                    file_path = os.path.join(root, filename)
                    module_name = os.path.splitext(os.path.basename(filename))[0]

                    # Dynamically import the module
                    spec = importlib.util.spec_from_file_location(module_name, file_path)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)

                    # Inspect the module to find functions with `skill_info`
                    for name, obj in inspect.getmembers(module, inspect.isfunction):
                        if hasattr(obj, "skill_info"):  # Check if the function has the `skill_info` attribute
                            skill_info = getattr(obj, "skill_info", {})
                            signature = inspect.signature(obj)

                            # Extract parameters from the signature
                            parameters = [
                                {
                                    "name": param.name,
                                    "default": param.default if param.default != inspect.Parameter.empty else None,
                                    "annotation": (
                                        param.annotation if param.annotation != inspect.Parameter.empty else ""
                                    ),
                                    "questions": [],
                                }
                                for param in signature.parameters.values()
                            ]

                            result[name] = {
                                "skill_info": skill_info,
                                "parameters": parameters,
                                "function": obj,  # Store the actual function object
                                "filename": filename,
                            }
        self.skills = result
        return result

    async def call_skill(self, function_name: str, robot: Robot = None, *args, **kwargs) -> Dict[str, Any]:
        """
        Call a registered skill asynchronously by its function name with parameter validation.

        Args:
            function_name (str): The name of the skill function.
            *args: Positional arguments to pass to the function.
            **kwargs: Keyword arguments to pass to the function.

        Returns:
            Dict[str, Any]: A dictionary containing the result, status, and any exception.

        Raises:
            ValueError: If the skill is not found or parameters are invalid.
        """
        if function_name not in self.skills:
            raise ValueError(f"Skill '{function_name}' not found.")

        skill_details = self.skills[function_name]
        function = skill_details["function"]
        parameters = skill_details["parameters"]

        # Validate kwargs
        expected_params = {param["name"]: param for param in parameters}
        for key in kwargs:
            if key not in expected_params:
                raise ValueError(f"Unexpected parameter '{key}' for skill '{function_name}'.")

        # Validate args
        for index, param in enumerate(parameters):
            if index >= len(args):
                break
            if param["annotation"] and not isinstance(args[index], param["annotation"]):
                raise TypeError(
                    f"Parameter '{param['name']}' expects type {param['annotation']}, " f"but got {type(args[index])}."
                )

        async def execute_skill():
            try:
                robot_needed = True in [param["name"] == "robot" for param in skill_details["parameters"]]
                if robot_needed:
                    kwargs["robot"] = robot
                LOG.info(f"Executing skill '{function_name}' with args={args}, kwargs={kwargs}.")
                if inspect.iscoroutinefunction(function):
                    result = await function(*args, **kwargs)
                else:
                    result = function(*args, **kwargs)
                return {"value": result, "status": "COMPLETED"}
            except asyncio.CancelledError:
                LOG.warning(f"Skill '{function_name}' was cancelled.")
                return {"value": None, "status": "CANCELLED"}
            except Exception as e:
                LOG.error(f"Error executing skill '{function_name}': {e}")
                return {"value": None, "status": "ERROR", "exception": str(e)}

        # Create a task to track the skill
        task = asyncio.create_task(execute_skill())
        self.running_skills[function_name] = task
        result = await task
        del self.running_skills[function_name]  # Remove from running skills after completion
        if inspect.isawaitable(result.get("value")):
            result["value"] = await result["value"]
        return result

    async def cancel_skill(self, function_name: str):
        """
        Cancel a running skill.

        Args:
            function_name (str): The name of the skill to cancel.
        """
        task = self.running_skills.get(function_name)
        if not task:
            LOG.warning(f"Skill '{function_name}' is not running.")
            return

        LOG.info(f"Cancelling skill '{function_name}'.")
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            LOG.info(f"Skill '{function_name}' cancelled successfully.")
        finally:
            self.running_skills.pop(function_name, None)

    async def update_skills(self):
        """
        Update running skills based on the current state of the directory.

        This stops skills that are now disabled or removed.
        """
        self.get_custom_skills_list()
        for skill_name in self.running_skills:
            if skill_name not in self.skills:
                await self.cancel_skill(skill_name)

    async def monitor_loop(self, interval: float = 1.0):
        """Continuously monitor the directory and update skills."""
        while True:
            try:
                await self.update_skills()
            except Exception as e:
                LOG.error(f"Error in the monitoring loop: {e}")
            await asyncio.sleep(interval)

    def list_running_skills(self) -> List[str]:
        """List all currently running skills."""
        return list(self.running_skills.keys())

    def serialize_skills(self) -> Dict[str, Any]:
        """
        Serialize skills for external usage, excluding the actual function object.

        Returns:
            Dict[str, Any]: Serialized skills dictionary.
        """
        return {
            skill_name: {
                "skill_info": serialize_data(details.get("skill_info", [])),
                "parameters": serialize_data(details.get("parameters", [])),
                "filename": serialize_data(details.get("filename", "")),
            }
            for skill_name, details in self.skills.items()
        }


def serialize_data(data: Any) -> Any:
    """Recursively check if there are vokarina types in data, and serialize them if needed.

    Args:
        data (any): Input data to serialize.

    Returns:
        any: Vokarina data serialized.
    """
    if isinstance(data, tuple):
        return tuple(serialize_data(item) for item in data)
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, Iterable) and not isinstance(data, (str, bytes)):
        return [serialize_data(item) for item in data]
    elif isinstance(data, (str, bool, int, float)):
        return data
    else:
        try:
            return json.dumps(data)
        except TypeError:
            return str(data)
    return data
