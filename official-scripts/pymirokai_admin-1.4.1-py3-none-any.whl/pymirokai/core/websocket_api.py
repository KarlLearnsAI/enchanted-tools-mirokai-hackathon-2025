#!/usr/bin/env python3
"""This module contains the WebSocketAPI class for communicating with the WebSocket."""
# TODO: Manage subscribers when deco/reco
import asyncio
import inspect
import logging
import json
from typing import Callable, Optional, Dict, Any

import websockets

from pymirokai.utils.json_parser import parse_json_recursively

logger = logging.getLogger("pymirokai")


class WebSocketAPI:
    """Class to handle WebSocket communication."""

    def __init__(self, retry_interval: int = 5) -> None:
        """Initialize the WebSocketAPI with the WebSocket URL.

        Args:
            retry_interval (int): The interval in seconds to wait before retrying the connection check.
        """
        self.ws_url: Optional[str] = None
        self.ws: Optional[websockets.WebSocketClientProtocol] = None
        self.get_jwt_token = None
        self.is_connected: bool = False
        self.retry_interval: int = retry_interval
        self.data: Dict[str, Any] = {}
        self.running = asyncio.Event()
        self.subscriptions = set()
        self.callbacks: Dict[str, Callable[[Dict[str, Any]], None]] = {}

    async def connect(self) -> None:
        """Connect to the WebSocket and start the data retrieval."""
        self.ws_url_with_token = f"{self.ws_url}?token={self.get_jwt_token()}"

        while self.running.is_set():
            try:
                async with websockets.connect(self.ws_url_with_token) as ws:
                    self.ws = ws
                    if not self.is_connected:
                        logger.info("Connected to WebSocket.")
                        for topic in self.subscriptions:  # reconnection to the subscribed topics
                            subscribe_message = json.dumps({"action": "subscribe", "topic": topic})
                            await self.ws.send(subscribe_message)
                            self.subscriptions.add(topic)
                        await self.subscribe("server_logs")
                    self.is_connected = True
                    await self._listen()
            except (
                websockets.exceptions.ConnectionClosedOK,
                websockets.exceptions.ConnectionClosedError,
                ConnectionError,
            ) as e:
                logger.error(f"WebSocket connection error: {e}. Closing.")
                self.is_connected = False

                await self.close()
            except Exception as e:  # pylint: disable=W0718
                logger.error(f"Unexpected error: {e}. Retrying in {self.retry_interval} seconds...")
                self.is_connected = False
                await asyncio.sleep(self.retry_interval)
            self.data = {}

    async def _listen(self) -> None:
        """Listen for messages from the WebSocket."""
        try:
            while self.is_connected and self.running.is_set():
                try:
                    message = await asyncio.wait_for(self.ws.recv(), timeout=5)
                    self._on_message(message)
                except asyncio.TimeoutError:
                    pass  # Timeout waiting for a message, continue listening
                except (websockets.exceptions.ConnectionClosedOK, websockets.exceptions.ConnectionClosedError) as e:
                    logger.warning(f"Connection closed: {e}")
                    self.is_connected = False
                    break
                except Exception as e:  # pylint: disable=W0718
                    logger.error(f"Error receiving message: {e}")
        finally:
            self.is_connected = False

    def _on_message(self, message: str) -> None:
        """WebSocket message event handler.

        Args:
            message (str): The received message.
        """
        try:
            msg = parse_json_recursively(message)
            if "name" not in msg or "type" not in msg or "data" not in msg:
                logger.error(f"Message {msg} not parsed.")
            self.data[msg["name"]] = {"type": msg["type"], "data": msg["data"]}
            # Call the callback function if registered
            if msg["name"] in self.callbacks:
                callback = self.callbacks[msg["name"]]
                if inspect.iscoroutinefunction(callback):
                    asyncio.create_task(callback(msg))
                else:
                    callback(msg)
                self.data[msg["name"]] = msg
        except json.JSONDecodeError as e:
            logger.error(f"Failed to decode message: {e}")

    def get_data(self) -> Dict[str, Any]:
        """Get the latest data received from the WebSocket.

        Returns:
            Dict[str, Any]: The latest data.
        """
        return self.data

    async def subscribe(self, topic: str) -> None:
        """Subscribe to a topic.

        Args:
            topic (str): The topic to subscribe to.
        """
        if self.is_connected and topic not in self.subscriptions:
            subscribe_message = json.dumps({"action": "subscribe", "topic": topic})
            await self.ws.send(subscribe_message)
            self.subscriptions.add(topic)
            logger.info(f"Subscribed to topic: {topic}")

    async def unsubscribe(self, topic: str) -> None:
        """Unsubscribe from a topic.

        Args:
            topic (str): The topic to unsubscribe from.
        """
        if self.is_connected and topic in self.subscriptions:
            unsubscribe_message = json.dumps({"action": "unsubscribe", "topic": topic})
            await self.ws.send(unsubscribe_message)
            self.subscriptions.remove(topic)
            logger.info(f"Unsubscribed from topic: {topic}")

    async def publish(self, topic: str, data: str) -> None:
        """Publish data to a topic.

        Args:
            topic (str): The topic to publish to.
            data (str): The data to publish (JSON format).
        """
        try:
            data_dict = parse_json_recursively(data)
            if "name" not in data_dict or "type" not in data_dict or "data" not in data_dict:
                logger.error(f"Wrong data format: {data}")
                return
        except json.JSONDecodeError:
            logger.error(f"Failed to decode JSON message: {data}")
            return

        if self.is_connected:
            publish_message = json.dumps({"action": "publish", "topic": topic, "data": data})
            await self.ws.send(publish_message)

    async def start(self, ws_url: str, get_jwt_token: callable) -> None:
        """Start the WebSocket connection.

        Args:
            ws_url (str): The url of the websocket
            get_jwt_token (callable): Callback to get the JWT token
        """
        self.ws_url = ws_url
        self.get_jwt_token = get_jwt_token
        self.running.set()
        await self.connect()

    async def close(self) -> None:
        """Close the WebSocket connection."""
        self.running.clear()
        if self.ws is not None:
            await self.ws.close()
        self.is_connected = False
        logger.info("WebSocket connection closed.")

    def register_callback(self, topic: str, callback: Callable[[Dict[str, Any]], None]) -> None:
        """Register a callback function for a topic.

        Args:
            topic (str): The topic to register the callback for.
            callback (Callable[[Dict[str, Any]], None]): The callback function to call when a
            message is received for the topic.
        """
        self.callbacks[topic] = callback
        logger.info(f"Callback registered for topic: {topic}")
