#!/usr/bin/env python3
"""This module contains enumerations for various features of the robot."""

from enum import Enum


class BackgroundExpression(Enum):
    """Enumeration for background expressions of the robot's face."""

    AMAZED = "emotion_amazed"
    ASLEEP = "emotion_asleep"
    DAZZLED = "emotion_dazzled"
    DETERMINED = "emotion_determined"
    EMBARASSED = "emotion_embarassed"
    HAPPY_BIG_SMILE = "emotion_happy_big_smile"
    INTEREST = "emotion_interest"
    JOY = "emotion_joy"
    NEUTRAL = "emotion_neutral"
    PERPLEXED = "emotion_perplexed"
    PRIDE = "emotion_pride"
    SADNESS = "emotion_sadness"
    SURPRISE = "emotion_surprise"


class AttentionPriority(Enum):
    """Enumeration for attention priority of the robot."""

    DEPOSIT_ZONE = "deposit_zone"
    EVERYTHING = "everything"
    FIREFLY = "firefly"
    HANDLES = "handles"
    HUMAN = "human"


class FaceAnim(Enum):
    """Enumeration of available face animations."""

    AMAZED = "emotion_amazed"
    DAZZLED = "emotion_dazzled"
    EMBARASSED = "emotion_embarassed"
    HAPPY_BIG_SMILE = "emotion_happy_big_smile"
    DETERMINED = "emotion_determined"
    INTEREST = "emotion_interest"
    JOY = "emotion_joy"
    NEUTRAL = "emotion_neutral"
    PRIDE = "emotion_pride"
    SADNESS = "emotion_sadness"
    SURPRISE = "emotion_surprise"
    PERPLEXED = "emotion_perplexed"


class EyesBehavior(Enum):
    """Enumeration for eyes behavior of the robot."""

    BROAD_LOOK_AWAY = "broad_look_away"
    EYE_WANDER = "eye_wander"
    IDLE = "idle"
    INFINITE_SHAPE = "infinite_shape"
    LOOK_DOWN = "look_down"
    LOOK_UP = "look_up"
    PIPED_RANDOM = "piped_random"
    STRAIGHT = "straight"


class GraspSide(Enum):
    """Enumeration for grasping side of the robot."""

    LEFT = "left"
    RIGHT = "right"


class Arm(Enum):
    """Enumeration for the arms of the robot."""

    LEFT = "left"
    RIGHT = "right"


class Hand(Enum):
    """Enumeration for the hands of the robot."""

    LEFT = "left"
    RIGHT = "right"


class Ear(Enum):
    """Enumeration for the ears of the robot."""

    LEFT = "left"
    RIGHT = "right"


class HandMode(Enum):
    """Enumeration for hand mode of the robot."""

    CLOSE_L = "close_l"
    CLOSE_R = "close_r"
    OPEN_L = "open_l"
    OPEN_R = "open_r"
    THUMB_DOWN_L = "thumb_down_l"
    THUMB_DOWN_R = "thumb_down_r"
    THUMB_UP_L = "thumb_up_l"
    THUMB_UP_R = "thumb_up_r"


class HeadMode(Enum):
    """Enumeration for head mode of the robot."""

    ANIMATE = "animate"
    FREEZE = "freeze"
    RESET = "reset"
    SCAN = "scan"
    TRACK_ATTENTION = "trackAttention"


class AccessLevel(Enum):
    # "ENCHANTER" skills will have access to all skills from "ENCHANTER" to the higher levels
    ENCHANTER: int = 10

    # "ADMIN" skills will have access to all skills from "ADMIN" to the higher levels
    ADMIN: int = 20

    # "USER" skills will have access to all skills from "USER" to the higher levels
    USER: int = 30
