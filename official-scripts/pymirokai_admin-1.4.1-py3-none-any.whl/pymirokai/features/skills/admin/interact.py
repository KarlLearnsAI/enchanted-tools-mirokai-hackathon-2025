#!/usr/bin/env python3
"""This module contains the interact-related features of the robot."""

from pymirokai.mission import Mission


class InteractAdmin:
    """Class to handle interact-related features of the robot."""

    def fake_asr(self, text: str) -> Mission:
        """Fake the Autonomous Speech Recognition to make the robot hear something.

        Args:
            text (str): The text to hear.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "fake_asr", text=text)
