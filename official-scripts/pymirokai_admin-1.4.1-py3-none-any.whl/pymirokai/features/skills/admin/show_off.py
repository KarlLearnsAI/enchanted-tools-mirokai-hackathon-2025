#!/usr/bin/env python3
"""This module contains the show_off-related features of the robot."""
from pymirokai.mission import Mission


class ShowOffAdmin:
    """Class to handle show_off-related features of the robot."""

    def fall_asleep(self) -> Mission:
        """Make the robot fall asleep.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "fall_asleep")
