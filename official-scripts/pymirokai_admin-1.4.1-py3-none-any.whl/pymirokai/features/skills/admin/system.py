"""This module contains system-related features of the robot."""

from pymirokai.mission import Mission


class SystemAdmin:
    """Class to handle system-related features of the robot."""

    def enable_motor_functions(self) -> Mission:
        """Calibrate and enable motor functions of the robot.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "enable_motor_functions")

    def get_ip(self) -> Mission:
        """Retrieve the robot's current IP address.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "get_ip")

    def update_prompt(self, prompt: str) -> Mission:
        """Update current prompt of the robot.

        Args:
            prompt (str): New prompt to use on the robot

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "update_prompt", prompt=prompt)

    def get_prompt(self) -> Mission:
        """Get current prompt of the robot.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "get_prompt")

    def clear_semantic_events(self) -> Mission:
        """Clear events list in semantic memory.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "get_ip")

    def reload_prompt(self) -> Mission:
        """Reload current prompts.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "get_prompt")

    def set_runtime_prompt(self, key: str, value: str) -> Mission:
        """Update a value for a key in the runtime prompt.

        Returns:
            key: Identifier of the runtime prompt. Not present in the prompt seen by the LLM.
            value: The runtime prompt value.
        """
        return Mission(self, "set_runtime_prompt", key=key, value=value)
