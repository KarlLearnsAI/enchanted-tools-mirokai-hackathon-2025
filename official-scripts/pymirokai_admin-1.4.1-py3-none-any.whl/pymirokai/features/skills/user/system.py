"""This module contains system-related features of the robot."""

from pymirokai.mission import Mission


class SystemUser:
    """Class to handle system-related features of the robot."""

    def get_battery_level(self) -> Mission:
        """Get current battery level.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "get_battery_level")
