#!/usr/bin/env python3
"""This module contains the manipulate-related features of the robot."""
from typing import Optional

from pymirokai.enums import Hand
from pymirokai.mission import Mission
from pymirokai.models.data_models import EnchantedObject
from pymirokai.utils.converter import hand_to_hand_entity_identifier


class ManipulateUser:
    """Class to handle manipulate-related features of the robot."""

    def close_hand(self, hand: Hand) -> Mission:
        """Close the robot's hand.

        Args:
            hand (Hand): The hand to close (left or right).

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "close_hand", hand=hand_to_hand_entity_identifier(hand))

    def close_both_hands(self) -> Mission:
        """Close the robot's hands.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "close_both_hands")

    def open_hand(self, hand: Hand) -> Mission:
        """Open the robot's hand.

        Args:
            hand (Hand): The hand to open (left or right).

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "open_hand", hand=hand_to_hand_entity_identifier(hand))

    def open_both_hands(self) -> Mission:
        """Open the robot's hands.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "open_both_hands")

    def open_hand_half(self, hand: Hand) -> Mission:
        """Open the robot's hand halfway.

        Args:
            hand (Hand): The hand to open halfway (left or right).

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "open_hand_half", hand=hand_to_hand_entity_identifier(hand))

    def put_object_in_front(self) -> Mission:
        """Put an object in front of the robot.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "put_object_in_front")

    def take_object_in_front(self, hand: Optional[Hand] = None) -> Mission:
        """Take an object in front of the robot.

        Args:
            hand (Optional[Hand]): The hand to use for taking the object.

        Returns:
            Mission: The mission representing the task.
        """
        if not hand:
            return Mission(self, "take_object_in_front")
        return Mission(self, "take_object_in_front", hand=hand_to_hand_entity_identifier(hand))

    def grasp_any_handle(self) -> Mission:
        """Grasp the handle in front of the robot.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "grasp_any_handle")

    def grasp_handle_with_left_hand(self) -> Mission:
        """Grasp the handle in front of the robot with left hand.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "grasp_handle_with_left_hand")

    def grasp_handle_with_right_hand(self) -> Mission:
        """Grasp the handle in front of the robot with right hand.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "grasp_handle_with_right_hand")

    def grasp_handle_with_human(self, rune: EnchantedObject) -> Mission:
        """Grasp a handle presented by a human.

        Args:
            rune (EnchantedObject): The rune object representing the handle to grasp.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "grasp_handle_with_human", rune=rune.id)

    def drop(self, rune: EnchantedObject) -> Mission:
        """Drop a handle.

        Args:
            rune_label: (str): The label associated with the handle's rune.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "drop", rune=rune.id)

    def drop_from_hand(self, hand: Hand) -> Mission:
        """Drop whatever is in the robot's hand.
        Ends up opening the hand.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "drop_from_hand", hand=hand_to_hand_entity_identifier(hand))
