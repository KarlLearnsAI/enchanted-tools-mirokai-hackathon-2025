#!/usr/bin/env python3
"""This module contains the show_off-related features of the robot."""
from typing import Optional
from pymirokai.mission import Mission
from pymirokai.enums import Hand
from pymirokai.utils.converter import hand_to_hand_entity_identifier


class ShowOffUser:
    """Class to handle show_off-related features of the robot."""

    def checkout_ears(self) -> Mission:
        """Check out the robot's ears.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "checkout_ears")

    def curl(self) -> Mission:
        """Perform a curl action.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "curl")

    def discover_body(self) -> Mission:
        """Discover the robot's body.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "discover_body")

    def fist_bump_posture(self, hand: Optional[Hand] = None) -> Mission:
        """Put the arm in a fist bump posture.

        Args:
            hand (Optional[Hand]): The hand to use for the fist bump.

        Returns:
            Mission: The mission representing the task.
        """
        if not hand:
            return Mission(self, "fist_bump_posture")
        return Mission(self, "fist_bump_posture", hand=hand_to_hand_entity_identifier(hand))

    def fist_bump(self, hand: Optional[Hand] = None) -> Mission:
        """Perform a fist bump with the specified arm, then the robot puts its arms down back.

        Args:
            hand (Optional[Hand]): The hand to use for the fist bump.

        Returns:
            Mission: The mission representing the task.
        """
        if not hand:
            return Mission(self, "fist_bump")
        return Mission(self, "fist_bump", hand=hand_to_hand_entity_identifier(hand))

    def give_both_hands(self) -> Mission:
        """Give both hands.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "give_both_hands")

    def give_hand(self) -> Mission:
        """Give a hand.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "give_hand")

    def nose_dive(self) -> Mission:
        """Perform a nose dive action.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "nose_dive")

    def raise_arms(self) -> Mission:
        """Raise the robot's arms.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "raise_arms")

    def show_off_with_arms(self) -> Mission:
        """Show off with the robot's arms.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "show_off_with_arms")

    def mirokai_spin(self) -> Mission:
        """Spin around.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "mirokai_spin")

    def wake_up_long(self) -> Mission:
        """Perform a long wake up action.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "wake_up_long")

    def wake_up_short(self) -> Mission:
        """Perform a short wake up action.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "wake_up_short")
