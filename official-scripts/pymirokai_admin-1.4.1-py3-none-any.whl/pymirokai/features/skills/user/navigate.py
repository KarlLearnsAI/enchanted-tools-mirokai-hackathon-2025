#!/usr/bin/env python3
"""This module contains the navigate-related features of the robot."""
from datetime import timedelta

from pymirokai.mission import Mission
from pymirokai.models.data_models import Coordinates, EnchantedUser, Rune, Location


class NavigateUser:
    """Class to handle navigate-related features of the robot."""

    def distribute_something_in_tray(self, what_is_in_the_tray: str) -> Mission:
        """Distributes an item in a tray by navigating to different locations and showing the tray to detected users.

        The function performs two things steps:
        1. Navigates to different locations and waits at each spot.
        2. If a user is detected
        2.1. We Cancel navigation
        2.2. We Show the tray to users
        2.3. We ask if he wants the item in the tray.

        Args:
            what_is_in_the_tray (str): What is in the tray.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "distribute_something_in_tray", what_is_in_the_tray=what_is_in_the_tray)

    def follow_user(self, rune: EnchantedUser) -> Mission:
        """Follow a user.

        Args:
            rune (EnchantedUser): The rune of the user to follow.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "follow_user", rune=rune)

    def go_to_absolute(self, coordinates: Coordinates) -> Mission:
        """Go to an absolute position.

        Args:
            coordinates (Coordinates): Coordinates for the absolute position.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "go_to_absolute", coordinates=coordinates.to_list())

    def go_to_relative(self, coordinates: Coordinates) -> Mission:
        """Go to a relative position.

        Args:
            coordinates (Coordinates): Coordinates for the relative position.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "go_to_relative", coordinates=coordinates.to_list())

    def go_to_rune(self, rune: Rune) -> Mission:
        """Go to a specific rune.

        Args:
            rune (Rune): The rune to go to.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "go_to_rune", rune=rune.id)

    def go_to_location(self, location: Location) -> Mission:
        """Go to a specific location.

        Args:
            location (Rune): The location to go to.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "go_to_location", location=location.id)

    def turn_to_rune(self, rune: Rune) -> Mission:
        """Turn specific rune and stop moving.

        Args:
            rune (Rune): The rune to turn to.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "turn_to_rune", rune=rune.id)

    def track_rune(self, rune: Rune) -> Mission:
        """Track a rune.

        Args:
            rune (Rune): The rune to track.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "track_rune", rune=rune.id)

    def move_backward(self, distance_meters: float = 1.0) -> Mission:
        """Move backward a certain distance.

        Args:
            distance_meters (float): The distance to move backward, in meters.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "move_backward", distance_meters=distance_meters)

    def move_forward(self, distance_meters: float = 1.0) -> Mission:
        """Move forward a certain distance.

        Args:
            distance_meters (float): The distance to move forward, in meters.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "move_forward", distance_meters=distance_meters)

    def move_left_side(self, distance_meters: float = 1.0) -> Mission:
        """Move left side a certain distance.

        Args:
            distance_meters (float): The distance to move on the left side, in meters.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "move_left_side", distance_meters=distance_meters)

    def move_right_side(self, distance_meters: float = 1.0) -> Mission:
        """Move right side a certain distance.

        Args:
            distance_meters (float): The distance to move on the right side, in meters.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "move_right_side", distance_meters=distance_meters)

    def stop_moving(self) -> Mission:
        """Stop the robot's movement.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "stop_moving")

    def teleoperate(self, enable: bool) -> Mission:
        """Enable or disable robot teleoperation.

        Args:
            enable (bool): Enable or disable teleoperation

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "teleoperate", enable=enable)

    def turn_left(self, degrees: float = 90.0, duration: timedelta = timedelta(seconds=-1.0)) -> Mission:
        """Turn the robot to the left by a specified angle.

        Args:
            degrees (float): The angle in degrees to turn left.
                Defaults to 90.0 degrees.
            duration (timedelta): The duration of the turn. Negative values indicate automatic calculation.
                Defaults to timedelta(seconds=-1.0).

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "turn_left", degrees=degrees, duration=duration)

    def turn_right(self, degrees: float = 90.0, duration: timedelta = timedelta(seconds=-1.0)) -> Mission:
        """Turn the robot to the right by a specified angle.

        Args:
            degrees (float): The angle in degrees to turn right.
                Defaults to 90.0 degrees.
            duration (timedelta): The duration of the turn. Negative values indicate automatic calculation.
                Defaults to timedelta(seconds=-1.0).

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "turn_right", degrees=degrees, duration=duration)

    def turn_back(self) -> Mission:
        """Turn back the robot.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "turn_back")

    def add_new_location_at_robot_position(self, location_name: str) -> Mission:
        """Add a new location in a persistent way where the robot is currently.

        Args:
            location_name (str): Name of the location to add.

        Returns:
            Mission: The mission representing the task.
        """
        return Mission(self, "add_new_location_at_robot_position", location_name=location_name)
