#!/usr/bin/env python3


class PlanningUser:
    """Class to handle planning features of the robot."""
