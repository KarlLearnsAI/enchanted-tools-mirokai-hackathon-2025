#!/usr/bin/env python3
"""This module contains the interaction-related features of the robot."""

from typing import Dict, Any
from pymirokai.utils.async_wrapper import make_async


class Interaction:
    """Class to handle interaction-related features of the robot."""

    @make_async
    def set_actions_by_voice(self, enabled: bool) -> Dict[str, Any]:
        """Activate or deactivate the trigger by voice.

        Args:
            enabled (bool): True to enable, False to disable.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_boolean("set_actions_by_voice", enabled)

    @make_async
    def set_sound_level(self, level: int) -> Dict[str, Any]:
        """Set the sound level of the robot.

        Args:
            level (int): The sound level (0-100).

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        if 0 <= level <= 100:
            return self.send_int("sound_level", level)
        raise ValueError("Sound level must be between 0 and 100")

    @make_async
    def is_sleeping(self) -> Dict[str, Any]:
        """Check if the robot is sleeping.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("is_sleeping")

    @make_async
    def is_seeing_human(self) -> Dict[str, Any]:
        """Check if the robot is seeing a human.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("is_seeing_human")

    @make_async
    def is_seeing_handle(self) -> Dict[str, Any]:
        """Check if the robot is seeing a handle.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("is_seeing_handle")

    @make_async
    def is_making_noise(self) -> Dict[str, Any]:
        """Check if the robot is making noise.

        Returns:
            Dict[str, Any]: The response from the REST API.
        """
        return self.send_command("is_making_noise")

    async def pddl_domain(self) -> str:
        """Print the last autonomous planning result.

        Returns:
            str: The last autonomous planning result.
        """
        return (await self.send_command("pddl_domain"))["result"].replace("\\n", "\n")

    async def pddl_problem(self) -> str:
        """Print the last autonomous planning result.

        Returns:
            str: The last autonomous planning result.
        """
        return (await self.send_command("pddl_problem"))["result"].replace("\\n", "\n")

    async def autonomous_planning_output(self) -> str:
        """Print the last autonomous planning result.

        Returns:
            str: The last autonomous planning result.
        """
        return (await self.send_command("autonomous_planning_output"))["result"].replace("\\n", "\n")
